$(document).ready(function(){
    //recuperar o carrinho
    carrinho = JSON.parse( localStorage.getItem( "carrinho") );

    if ( !carrinho ) {
        $("#msg").html("<p class='center-align'>Seu carrinho está vazio</p>");
    } else {

        total = 0;
        $.each( carrinho, function ( key, val ) {

            i = parseInt(key) + 1;
            //formatar o valor
            valor = formatarValor ( parseFloat ( val.valor ), "br" );
            //somar o total
            total = parseFloat( total ) + parseFloat ( val.valor );
            //inserir os dados na tabela
            $("#carrinho tbody").append(`
				<tr class="linha${key}">
					<td><img src="${val.foto}" alt="${val.produto}" width="30px"></td>
					<td>${val.produto}</td>
					<td>${val.qtde}</td>
					<td>${valor}</td>
				</tr>`);
            valor = formatarValor( parseFloat ( val.valor ) , "us" );
            //popular os produtos
            $("#produtos").append(`
				<input name="itemId${i}" type="hidden" value="${i}">  
		        <input name="itemDescription${i}" type="hidden" value="${val.produto}">  
		        <input name="itemAmount${i}" type="hidden" value="${valor}">  
		        <input name="itemQuantity${i}" type="hidden" value="${val.qtde}">  
		        <input name="itemWeight${i}" type="hidden" value="1000">  
			`);
        });
        //formatado para o pagseguro
        vtotal = formatarValor( parseFloat(total) , "us" );
        //formatado em Reais
        total = formatarValor( parseFloat(total), "br" );
        //adicionar o valor total na tabela
        $("#carrinho tbody").append(`
			<tr>
				<td colspan="3">TOTAL</td>
				<td>${total}</td>
			</tr>
		`);
    }
})
