//funcao para formatar os valores
function formatarValor(valor, formato) {
    if (formato == "br") {
        valor = valor.toLocaleString("pt-BR", {style: "currency", currency: "BRL"});
    } else {

        valor = valor.toLocaleString("en-US", {minimumFractionDigits: 2});
    }
    return valor;
}

//funcao para preencher os produtos na tela
function preencher(dados) {
    $.each(dados, function (key, val) {

        valor = formatarValor(parseFloat(val.valor), "br");

        $("#produtos").append(`
			<div class="col s12 m6 center-align">
				<div class="card">
					<img src="${val.foto}" alt="${val.produto}" class="responsive-img">
					<h2>${val.produto}</h2>
					<p class="valor">${valor}</p>
					<a href="produto/${val.id}" class="btn red">Detalhes</a>
				</div>
			</div>
		`);

        $("#msg").html("");

    })
}

//mostrar todas as categorias no menu
$(document).ready(function () {
    //buscar as categoria do cache
    categoria = localStorage.getItem("categoria");

    if (categoria) {
        dados = JSON.parse(categoria);
        preencherCategorias(dados);
    } else {

        url = "../json/categoria.php?op=categorias";
        $.getJSON(url, function () {

        }).done(function (dados) {
            localStorage.setItem("categoria", JSON.stringify(dados));
            preencherCategorias(dados);
        }).fail(function () {

        });
    }
});

//funcao para carregar o menu de categorias
function preencherCategorias(dados) {
    $.each(dados, function (key, val) {

        $("#menu-categorias").append(`
			<li>
				<a href="categoria/${val.id}">
					${val.categoria}
				</a>
			</li>
		`);

    })
}

if (navigator.serviceWorker) {
    console.log("ServiceWorkerssupported");

    navigator.serviceWorker.register('http://localhost/sw.js', {
        scope: './'
    })
        .then(function (reg) {
            console.log("ServiceWorkerstered", reg);
        })
        .catch(function (error) {
            console.log("Failedegister ServiceWorker", error);
        });
}

let deferredPrompt;
const addBtn = document.querySelector('#instalar');

window.addEventListener('beforeinstallprompt', (e) => {
    if (!addBtn) { return; }

    console.log('prmpt de instlç');
    e.preventDefault();
    deferredPrompt = e;
    addBtn.addEventListener('click', (e) => {
        addBtn.style.display = 'none';
        deferredPrompt.prompt();

        deferredPrompt.userChoice.then(choiceResult => {
            if (!choiceResult.outcome === 'accepted') {
                addBtn.style.display = 'block';
                return;
            }

            console.log(choiceResult.outcome);
        })
    });
})
//se esta instalado
window.addEventListener('appinstalled', (evt) => {
    console.log('a2hs instalado');
});

