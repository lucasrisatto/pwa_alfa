$(document).ready(function(){

	destaques = localStorage.getItem("destaques");

	if ( destaques ) {
		//tem algo no cache
		console.log("Informações do cache");
		dados = JSON.parse( destaques );
		preencher( dados );

	} else {
		//vai buscar no json
		console.log("Informações do JSON");
		url = "../json/produtos.php?op=destaques";
		//jquery para buscar as informações
		$.getJSON(url, function() {
			$("#msg").html(`
				<p class="center-align">
					<img src="images/load.gif" alt="Carregando"><br>Aguarde, carregando dados...
				</p>
			`);
		}).done( function( dados ) {

			console.log("Guardando dados no cache");
			localStorage.setItem("destaques", JSON.stringify( dados ));
			preencher( dados );

		}).fail(function(){
			$("#msg").html("Erro ao realizar busca");
		});
	}
});