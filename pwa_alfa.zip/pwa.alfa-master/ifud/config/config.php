<?php
	/*
	* definições para conexão com o banco de dados
	*/
	try {

		define("SERVER","xxxxxxx");
		define("DB","xxxxx");
		define("USER","xxxx");
		define("PWD","xxxxx");	
	
		$pdo = new PDO ("mysql:host=".SERVER.";dbname=".DB.";charset=utf8",USER,PWD);

	} catch (PDOException $e) {

		echo "<div class='alert alert-danger'>Erro ao conectar no banco de dados: " . $e->getMessage()."</div>";
		exit;

	}
