<button type="submit" id="instalar" class="btn red darken-4">Instalar Aplicativo</button>

<h1 class="center-align">
	Destaques
</h1>

<div class="row" id="produtos">

</div>