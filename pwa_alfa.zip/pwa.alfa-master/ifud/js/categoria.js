$(document).ready(function(){
	//pegar a categoria
	categoria = localStorage.getItem("categoria"+id);

	if ( categoria ) {
		dados = JSON.parse( categoria );
		preencher( dados );
	} else {
		url = "../json/categoria.php?op=categoria&id="+id;
		$.getJSON(url, function(){

		}).done( function ( dados ) {

			localStorage.setItem("categoria"+id, JSON.stringify( dados ) );
			preencher( dados );

		}).fail( function () {

		})
	}
});