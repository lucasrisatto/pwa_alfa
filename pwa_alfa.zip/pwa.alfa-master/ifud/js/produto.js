$(document).ready(function () {

    //recuperar o produto do cache
    produto = localStorage.getItem("produto" + id);

    //verificar se tem o produto
    if (produto) {
        //carregar o produto do cache

        //converser os dados para JSON
        dados = JSON.parse(produto);
        //preencher a tela
        preencherProduto(dados);

    } else {
        //buscar o produto do json

        url = "../json/produtos.php?op=produto&id=" + id;
        $.getJSON(url, function () {
            //mostrar a mensagem dentro do msg
            $("#msg").html("<img src='images/load.gif' alt='Carregando'> Carregando dados.");

        }).done(function (dados) {

            //inserir o produto no cach - localStorage
            localStorage.setItem("produto" + id, JSON.stringify(dados));
            //preencher
            preencherProduto(dados);
        }).fail(function () {
            $("#msg").html("Erro ao buscar produto");
        });
    }
})


//funcao para mostrar o produto na tela
function preencherProduto(dados) {
    $.each(dados, function (key, val) {
        $("h1").html(val.produto);

        valor = formatarValor(parseFloat(val.valor), "br");

        $(".produto").html(`
			<img src="${val.foto}" alt="${val.produto}" class="responsive-img">
			<h2>${val.produto}</h2>
			<p>${val.ingredientes}</p>
			<p class="valor">${valor}</p>
			<button type="button" class="btn red darken-4" onclick="adicionar(${val.id})">Adicionar ao Pedido</button>
		`);
        //retirar a mensagem de aguardando
        $("#msg").html("");
    });
}

//funcao para adicionar produto no carrinho
function adicionar(id) {

    //pegar do JSON
    dados = JSON.parse(localStorage.getItem("produto" + id));

    $("#msg").html(`
			<img src="images/load.gif" alt="Carregando">
			Aguarde, carregando
		`);
    //rolar a tela para riba
    $(document).scrollTop(0);

    //se nao tem dados
    if (!dados) {

        url = "../json/produtos.php?op=produto&id=" + id;
        $.getJSON(url, function () {
            //colocar a mensagem
        }).done(function (dados) {

            //inserir o produto no cach - localStorage
            localStorage.setItem("produto" + id, JSON.stringify(dados));

        }).fail(function () {
            $("#msg").html("Erro ao buscar produto");
        });

    }

    //carrinho de compras
    carrinho = JSON.parse(localStorage.getItem("carrinho"));

    if (!carrinho) {
        //iniciar o carrinho
        carrinho = [];
    }

    //jogar o produto dentro do carrinho
    $.each(dados, function (key, val) {

        var {q, index} = buscaItem(carrinho, val.id)

        if (q == 0) {
            //nao existe item
            console.log("Não existe item");
            //criar o item do carrinho
            item = {
                id: val.id,
                produto: val.produto,
                valor: val.valor,
                foto: val.foto,
                qtde: 1
            };
            //jogar o item dentro do carrinho
            carrinho.push(item);
            //atualizar o localStorage
            localStorage.setItem("carrinho", JSON.stringify(carrinho));
        } else {
            //existe item
            console.log("Existe item");
            console.log(carrinho[index]);
            carrinho[index].qtde += 1;
            carrinho[index].valor = val.valor * carrinho[index].qtde;
            localStorage.setItem('carrinho', JSON.stringify(carrinho));
        }

    });
    //chamar a funcaom para preencher
    preencherCarrinho(carrinho);
    //abrir o modal
    $("#modalCarrinho").modal("open");
}

//buscar item no carrinho
function buscaItem(carrinho, id) {
    var q = 0;
    var index = null;

    $.each(carrinho, function (key, val) {
        if (val.id == id) {
            q++;
            index = key;
        }
    });

    return {q, index};
}

//preencher o carrinho no modal
function preencherCarrinho(dados) {

    total = 0;

    $.each(dados, function (key, val) {
        //formatar o valor
        valor = formatarValor(parseFloat(val.valor), "br");
        //somar o total
        total = parseFloat(total) + parseFloat(val.valor);
        //inserir os dados na tabela
        $("#modalCarrinho tbody").append(`
			<tr class="linha${key}">
				<td><img src="${val.foto}" alt="${val.produto}" width="30px"></td>
				<td>${val.produto}</td>
				<td>${val.qtde}</td>
				<td>${valor}</td>
				<td><a href="javascript:remover(${key})" class="btn red">
					<i class="material-icons">clear</i>
				</td>
			</tr>`);
    });
    //formatar o valor total e mostra na tela
    total = formatarValor(parseFloat(total), "br");
    $("#modalCarrinho tbody").append(`
		<tr id="totalCarrinho">
			<td colspan="3">TOTAL:</td>
			<td>${total}</td>
		</tr>
	`);
}

function remover(id) {
    if (confirm("Deseja mesmo remover")) {
        total = 0;
        carrinho = JSON.parse(localStorage.getItem("carrinho"));

        carrinho.splice(id, 1);

        $.each(carrinho, function (key, val) {
            //somar o total
            total = parseFloat(total) + parseFloat(val.valor);
        });

        carrinho = JSON.stringify(carrinho);
        localStorage.setItem("carrinho", carrinho);

        $(".linha" + id).hide();

        total = formatarValor(parseFloat(total), "br");
        $("#totalCarrinho td:nth-child(2)").text(total);
    }
}
