<div class="center-align">
	<h1><img src="images/offline.png" class="responsive-img" title="offline"></h1>
	<h2>You are offline!!!!</h2>
</div>