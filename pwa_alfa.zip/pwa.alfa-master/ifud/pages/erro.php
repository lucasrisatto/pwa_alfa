<div class="container">
	<h1 class="center-align">
		<img src="images/404.jpg" alt="404" title="404" class="responsive-img">
	</h1>
	<blockquote>
		<p>A página que está tentando acessar não existe ou foi removida.</p>
		<p>Por favor tente novamente.</p>
		<p>Ou <a href="javascript:history.back()">volte para a página anterior</a>.</p>
	</blockquote>
</div>
